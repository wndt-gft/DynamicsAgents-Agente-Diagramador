# Tools for tourism_specialist\n\nEste diretório pode acomodar ferramentas específicas do agente.
