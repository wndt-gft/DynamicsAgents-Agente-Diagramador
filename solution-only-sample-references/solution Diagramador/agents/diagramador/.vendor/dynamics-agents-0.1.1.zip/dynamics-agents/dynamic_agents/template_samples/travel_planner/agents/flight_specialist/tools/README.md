# Tools for flight_specialist\n\nEste diretório pode acomodar ferramentas específicas do agente.
