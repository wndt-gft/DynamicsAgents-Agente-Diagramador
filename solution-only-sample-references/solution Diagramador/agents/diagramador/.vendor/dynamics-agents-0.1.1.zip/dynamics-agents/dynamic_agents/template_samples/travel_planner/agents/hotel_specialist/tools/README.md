# Tools for hotel_specialist\n\nEste diretório pode acomodar ferramentas específicas do agente.
