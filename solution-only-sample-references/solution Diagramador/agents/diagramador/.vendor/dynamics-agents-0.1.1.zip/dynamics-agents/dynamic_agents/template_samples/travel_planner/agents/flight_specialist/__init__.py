"""Componentes Python do agente."""

from .agent import run

__all__ = ["run"]
